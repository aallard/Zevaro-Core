#!/bin/bash
# Start Zevaro infrastructure

set -e

echo "Starting Zevaro infrastructure..."

cd "$(dirname "$0")/.."

# Start services
docker-compose up -d postgres redis zookeeper kafka

# Wait for services to be healthy
echo "Waiting for services to be ready..."
sleep 10

# Initialize Kafka topics
docker-compose up kafka-init

echo ""
echo "Infrastructure ready!"
echo ""
echo "Services:"
echo "  - PostgreSQL: localhost:5432 (user: zevaro, pass: zevaro, db: zevaro)"
echo "  - Redis:      localhost:6379"
echo "  - Kafka:      localhost:9092"
echo ""
echo "To view logs:  docker-compose logs -f"
echo "To stop:       docker-compose down"
