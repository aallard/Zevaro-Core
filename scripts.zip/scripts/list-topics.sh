#!/bin/bash
# List Kafka topics

docker exec zevaro-kafka kafka-topics --list --bootstrap-server localhost:9092
