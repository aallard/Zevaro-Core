#!/bin/bash
# Stop Zevaro infrastructure

set -e

echo "Stopping Zevaro infrastructure..."

cd "$(dirname "$0")/.."

docker-compose down

echo "Infrastructure stopped"
